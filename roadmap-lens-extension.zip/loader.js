/* Roadmap Lens — page loader (content script).
 * Asks the background updater for the newest verified bundle and runs it in the Jira page.
 * The bundle sets <html data-roadmap-lens="<build>"> when it starts (handy for support/debugging). */
(async () => {
  if (document.getElementById('roadmap-lens-config')) return;
  const DEFAULTS = { enabled: true, autoOpen: true, boards: ['314'] };
  const { settings = {} } = await chrome.storage.local.get('settings');
  const s = { ...DEFAULTS, ...settings };
  if (!s.enabled) return;

  const bundle = await chrome.runtime.sendMessage({ type: 'lens:get-bundle' });
  if (!bundle?.code) return console.warn('[Roadmap Lens] no bundle', bundle?.error);

  const cfg = document.createElement('script');
  cfg.type = 'application/json';
  cfg.id = 'roadmap-lens-config';
  cfg.textContent = JSON.stringify({
    ...s,
    fontUrl: chrome.runtime.getURL('fonts/Vazirmatn-Variable.woff2'),
    build: bundle.build,
    source: bundle.source,
  });
  document.documentElement.appendChild(cfg);

  // Chrome blocks <script> tags injected by a content script (extension CSP), so the background
  // worker runs the verified bundle in the page's main world via chrome.scripting.
  const r = await chrome.runtime.sendMessage({ type: 'lens:inject-main' });
  if (!r?.ok) console.warn('[Roadmap Lens] could not start:', r?.error || 'blocked by the page');

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'lens:updated') document.dispatchEvent(new CustomEvent('roadmap-lens:updated', { detail: { build: msg.build } }));
  });
})();
