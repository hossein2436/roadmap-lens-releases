/* Roadmap Lens — page loader (content script).
 * Asks the background updater for the newest verified bundle and runs it in the Jira page.
 * The bundle sets <html data-roadmap-lens="<build>"> when it starts (handy for support/debugging). */
(async () => {
  if (document.getElementById('roadmap-lens-config')) return;
  const DEFAULTS = { enabled: true, autoOpen: true, boards: ['314'] };
  const { settings = {} } = await chrome.storage.local.get('settings');
  const s = { ...DEFAULTS, ...settings };
  if (!s.enabled) return;

  const bundle = await chrome.runtime.sendMessage({ type: 'lens:get-bundle' });
  if (!bundle?.code) return console.warn('[Roadmap Lens] no bundle', bundle?.error);

  const cfg = document.createElement('script');
  cfg.type = 'application/json';
  cfg.id = 'roadmap-lens-config';
  cfg.textContent = JSON.stringify({
    ...s,
    fontUrl: chrome.runtime.getURL('fonts/Vazirmatn-Variable.woff2'),
    build: bundle.build,
    source: bundle.source,
  });
  document.documentElement.appendChild(cfg);

  // Narrow request bridge. No credential is ever sent into the page.
  // The page may only name a SIF key: this content script (isolated from page scripts) looks up that
  // issue's own BRD link in Jira, so nothing on the page can make the extension read an arbitrary document.
  const SIF_KEY = /^SIF-\d{1,7}$/;
  const BRD_FIELD = 'customfield_16105';
  const docs = new Map(); // key → { text, url } read by this content script in this page
  const jira = async (key) => {
    const r = await fetch(`${location.origin}/rest/api/2/issue/${encodeURIComponent(key)}?fields=${BRD_FIELD},parent`, { credentials: 'same-origin', headers: { Accept: 'application/json' } });
    if (!r.ok) throw new Error(r.status === 404 ? 'این SIF پیدا نشد یا اجازهٔ دیدنش را ندارید.' : `خواندن SIF از جیرا ممکن نشد (خطای ${r.status}).`);
    return r.json();
  };
  const linkOf = (value) => ((typeof value === 'string' ? value : '').match(/https:\/\/[^\s\]<>|"]+/) || [''])[0];
  async function brdLink(key) {
    const issue = await jira(key);
    let url = linkOf(issue.fields?.[BRD_FIELD]);
    const parent = issue.fields?.parent?.key;
    if (!url && parent && SIF_KEY.test(parent)) url = linkOf((await jira(parent)).fields?.[BRD_FIELD]);
    if (!url) throw new Error('لینک BRD روی این SIF ثبت نشده است.');
    return url;
  }
  async function handle(d) {
    if (d.type === 'brd:key-status') return chrome.runtime.sendMessage({ type: 'brd:key-status' });
    if (!SIF_KEY.test(d.key || '')) return { error: 'شناسهٔ SIF معتبر نیست.' };
    if (d.type === 'brd:read') {
      const url = await brdLink(d.key);
      const r = await chrome.runtime.sendMessage({ type: 'brd:read', url });
      if (r?.text) docs.set(d.key, { text: r.text, url });
      return r?.error ? r : { text: r.text, url };
    }
    if (d.type === 'brd:evaluate') {
      // Typed text (for non-Google sources or a single section) is the user's own input; otherwise only
      // the document this script read for the same SIF is sent.
      const manual = typeof d.text === 'string' && d.text.trim() ? d.text : '';
      const text = manual || docs.get(d.key)?.text;
      if (!text) return { error: 'اول متن سند همین SIF باید خوانده شود.', code: 'read' };
      return chrome.runtime.sendMessage({ type: 'brd:evaluate', text });
    }
    return { error: 'درخواست شناخته نشد.' };
  }
  document.addEventListener('fanoos:brd-request', async (event) => {
    const d = event.detail;
    if (!d || !['brd:read','brd:evaluate','brd:key-status'].includes(d.type) || typeof d.id !== 'string') return;
    let result;
    try { result = await handle(d); }
    catch (e) { result = { error: e?.message && !/Extension context/i.test(e.message) ? e.message : 'ارتباط با افزونه قطع شد؛ صفحه را تازه کنید.' }; }
    document.dispatchEvent(new CustomEvent('fanoos:brd-response', { detail: { id: d.id, result } }));
  });
  // Chrome blocks <script> tags injected by a content script (extension CSP), so the background
  // worker runs the verified bundle in the page's main world via chrome.scripting.
  const r = await chrome.runtime.sendMessage({ type: 'lens:inject-main' });
  if (!r?.ok) console.warn('[Roadmap Lens] could not start:', r?.error || 'blocked by the page');

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'lens:updated') document.dispatchEvent(new CustomEvent('roadmap-lens:updated', { detail: { build: msg.build } }));
  });
})();
