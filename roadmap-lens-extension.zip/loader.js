/* Roadmap Lens — page loader (content script).
 * Asks the background updater for the newest verified bundle and runs it in the Jira page. */
(async () => {
  if (document.getElementById('roadmap-lens-config')) return;
  const DEFAULTS = { enabled: true, autoOpen: true, boards: ['314'] };
  const { settings = {} } = await chrome.storage.local.get('settings');
  const s = { ...DEFAULTS, ...settings };
  if (!s.enabled) return;

  const bundle = await chrome.runtime.sendMessage({ type: 'lens:get-bundle' });
  if (!bundle?.code) return console.warn('[Roadmap Lens] no bundle', bundle?.error);

  const cfg = document.createElement('script');
  cfg.type = 'application/json';
  cfg.id = 'roadmap-lens-config';
  cfg.textContent = JSON.stringify({
    ...s,
    fontUrl: chrome.runtime.getURL('fonts/Vazirmatn-Variable.woff2'),
    build: bundle.build,
    source: bundle.source,
  });
  document.documentElement.appendChild(cfg);

  const run = (useInline) =>
    new Promise((resolve, reject) => {
      const el = document.createElement('script');
      if (useInline) {
        el.textContent = bundle.code;
        document.documentElement.appendChild(el);
        el.remove();
        resolve();
        return;
      }
      el.src = URL.createObjectURL(new Blob([bundle.code], { type: 'text/javascript' }));
      el.onload = () => (URL.revokeObjectURL(el.src), el.remove(), resolve());
      el.onerror = () => (el.remove(), reject(new Error('blob script blocked')));
      document.documentElement.appendChild(el);
    });
  try {
    await run(false);
  } catch {
    await run(true); // page CSP refused blob: — fall back to an inline script
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'lens:updated') document.dispatchEvent(new CustomEvent('roadmap-lens:updated', { detail: { build: msg.build } }));
  });
})();
