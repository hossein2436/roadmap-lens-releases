/* Shared by the extension worker and offline contract tests. */
(function(root) {
  const levels = { excellent: 'خیلی خوب', suitable: 'نسبتاً مناسب', weak: 'ضعیف' };
  function validate(value) {
    if (!value || !Object.hasOwn(levels, value.level) || typeof value.reason !== 'string' || !value.reason.trim() || value.reason.length > 500 || !Array.isArray(value.suggestions) || value.suggestions.length > 2 || value.suggestions.some(x => typeof x !== 'string' || !x.trim() || x.length > 250)) throw new Error('پاسخ ارزیابی معتبر نیست؛ دوباره تلاش کنید.');
    return { level: value.level, reason: value.reason.trim(), suggestions: value.suggestions.map(x => x.trim()) };
  }
  function reviewers(fields) {
    const product = fields.customfield_18404;
    const people = (Array.isArray(product) ? product : product ? [product] : []).filter(x => x?.name);
    return people.length ? people : fields.assignee?.name ? [fields.assignee] : [];
  }
  const engine = { levels, validate, reviewers };
  root.LENS_BRD = engine;
  if (typeof module !== 'undefined') module.exports = engine;
})(globalThis);
