/* Where the extension looks for new versions, and the key that must have signed them.
 * Changing anything here means teammates need to reinstall the extension once. */
self.LENS_CONFIG = {
  shellVersion: 3,
  checkEveryMinutes: 30,
  // Tried in order; the second is a CDN mirror of the same public repo (useful if raw.githubusercontent.com is slow or filtered).
  releaseUrls: [
    'https://raw.githubusercontent.com/hossein2436/roadmap-lens-releases/main/',
    'https://cdn.jsdelivr.net/gh/hossein2436/roadmap-lens-releases@main/',
  ],
  // ECDSA P-256 public key. Only bundles signed with the matching private key are installed.
  publicKeyJwk: {"kty":"EC","crv":"P-256","x":"2SWxv1QQM0o2hi-8pQdtpLiKN1RmRRUW4UHp3TpSpwk","y":"VCNJWLE6YUXuorFHOtuBVPP75NQVPhNOUlEDkiQBmU0"},
};
