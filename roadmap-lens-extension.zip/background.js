/* Roadmap Lens — background updater.
 * Checks the public releases repo for a newer build, verifies its SHA-256 and ECDSA signature,
 * stores it, and hands it to the page loader. The copy packaged with the extension is the fallback. */
importScripts('config.js');
const C = self.LENS_CONFIG;
const JIRA_TABS = 'https://jira-it.snappfood.ir/*';

const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
const fromB64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

let packagedMetaCache = null;
async function packagedMeta() {
  if (!packagedMetaCache) packagedMetaCache = await fetch(chrome.runtime.getURL('dist/build.json')).then((r) => r.json());
  return packagedMetaCache;
}

/** The newest bundle we are allowed to run: downloaded (if newer) or packaged. */
async function currentBundle() {
  const pkg = await packagedMeta();
  const { bundle } = await chrome.storage.local.get('bundle');
  if (bundle?.code && bundle.build > pkg.build) return { code: bundle.code, build: bundle.build, version: bundle.version, source: 'remote' };
  const code = await fetch(chrome.runtime.getURL('dist/lens.js')).then((r) => r.text());
  return { code, build: pkg.build, version: pkg.version, source: 'packaged' };
}

async function verifySignature(bytes, sigB64) {
  if (!C.publicKeyJwk) throw new Error('no public key configured');
  const key = await crypto.subtle.importKey('jwk', C.publicKeyJwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
  return crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, fromB64(sigB64), bytes);
}

async function fetchOk(url, as) {
  const r = await fetch(url, { cache: 'no-store' });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return as === 'json' ? r.json() : r.arrayBuffer();
}

let running = null;
function checkForUpdate() {
  running ||= (async () => {
    const pkg = await packagedMeta();
    const { bundle } = await chrome.storage.local.get('bundle');
    const have = Math.max(pkg.build, bundle?.build || 0);
    const status = { checkedAt: Date.now(), running: have, ok: false };
    const errors = [];
    for (const base of C.releaseUrls) {
      try {
        const latest = await fetchOk(`${base}latest.json?t=${Date.now()}`, 'json');
        status.latest = latest.build;
        if (latest.minShell && latest.minShell > C.shellVersion) {
          status.ok = true;
          status.shellOutdated = true;
          break;
        }
        if (!(latest.build > have)) {
          status.ok = true;
          break;
        }
        const buf = await fetchOk(base + latest.file);
        if (hex(await crypto.subtle.digest('SHA-256', buf)) !== latest.sha256) throw new Error('hash mismatch');
        if (!(await verifySignature(buf, latest.sig))) throw new Error('signature rejected');
        const code = new TextDecoder().decode(buf);
        await chrome.storage.local.set({ bundle: { code, build: latest.build, version: latest.version, at: Date.now() } });
        status.ok = true;
        status.updated = latest.build;
        status.running = latest.build;
        notifyTabs(latest.build);
        break;
      } catch (e) {
        errors.push(`${new URL(base).host}: ${e.message}`);
      }
    }
    if (!status.ok) status.error = errors.join(' | ');
    await chrome.storage.local.set({ updateStatus: status });
    return status;
  })().finally(() => (running = null));
  return running;
}

async function notifyTabs(build) {
  const tabs = await chrome.tabs.query({ url: JIRA_TABS });
  tabs.forEach((t) => chrome.tabs.sendMessage(t.id, { type: 'lens:updated', build }).catch(() => {}));
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('lens-update', { periodInMinutes: C.checkEveryMinutes, delayInMinutes: 1 });
  checkForUpdate();
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create('lens-update', { periodInMinutes: C.checkEveryMinutes, delayInMinutes: 1 });
  checkForUpdate();
});
chrome.alarms.onAlarm.addListener((a) => a.name === 'lens-update' && checkForUpdate());

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === 'lens:get-bundle') {
    currentBundle().then(reply, (e) => reply({ error: e.message }));
    return true;
  }
  if (msg?.type === 'lens:check') {
    checkForUpdate().then(reply, (e) => reply({ ok: false, error: e.message }));
    return true;
  }
  if (msg?.type === 'lens:info') {
    Promise.all([packagedMeta(), chrome.storage.local.get(['bundle', 'updateStatus'])]).then(([pkg, s]) =>
      reply({
        packaged: pkg.build,
        remote: s.bundle?.build || 0,
        running: Math.max(pkg.build, s.bundle?.build || 0),
        status: s.updateStatus || null,
        shellVersion: C.shellVersion,
      })
    );
    return true;
  }
  return false;
});
