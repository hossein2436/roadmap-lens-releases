const DEFAULTS = { enabled: true, autoOpen: true, boards: ['314'] };
const $ = (id) => document.getElementById(id);
const fa = (n) => new Intl.NumberFormat('fa-IR', { useGrouping: false }).format(n);
const rtf = new Intl.RelativeTimeFormat('fa', { numeric: 'auto' });
const ago = (t) => {
  const m = Math.round((t - Date.now()) / 60000);
  return Math.abs(m) < 1 ? 'همین حالا' : Math.abs(m) < 60 ? rtf.format(m, 'minute') : rtf.format(Math.round(m / 60), 'hour');
};

function showStatus(info) {
  $('build').textContent = fa(info.running);
  const s = info.status;
  let text = info.remote > info.packaged ? 'آخرین نسخه از گیت‌هاب دریافت شده.' : 'نسخه‌ی همراه افزونه.';
  if (s?.shellOutdated) text = 'نسخه‌ی تازه به نصب دوباره‌ی افزونه نیاز دارد؛ پوشه‌ی جدید را از مسئول افزونه بگیرید.';
  else if (s?.updated) text = `به‌روز شد؛ صفحه‌ی جیرا را تازه کنید.`;
  else if (s && !s.ok) text = `بررسی ناموفق بود (${s.error || 'شبکه'}). با نسخه‌ی فعلی کار می‌کند.`;
  else if (s?.checkedAt) text += ` آخرین بررسی ${ago(s.checkedAt)}.`;
  $('update-text').textContent = text;
}

async function init() {
  const { settings = {} } = await chrome.storage.local.get('settings');
  const s = { ...DEFAULTS, ...settings };
  $('enabled').checked = s.enabled;
  $('autoOpen').checked = s.autoOpen;
  $('boards').value = s.boards.join(', ');
  $('open').href = `https://jira-it.snappfood.ir/secure/RapidBoard.jspa?rapidView=${s.boards[0] || '314'}`;

  const save = async () => {
    const boards = $('boards')
      .value.split(/[,\s،]+/)
      .map((x) => x.replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
      .filter((x) => /^\d+$/.test(x));
    const next = { enabled: $('enabled').checked, autoOpen: $('autoOpen').checked, boards: boards.length ? boards : DEFAULTS.boards };
    await chrome.storage.local.set({ settings: next });
    $('open').href = `https://jira-it.snappfood.ir/secure/RapidBoard.jspa?rapidView=${next.boards[0]}`;
  };
  ['enabled', 'autoOpen'].forEach((id) => $(id).addEventListener('change', save));
  $('boards').addEventListener('change', save);

  showStatus(await chrome.runtime.sendMessage({ type: 'lens:info' }));
  $('check').addEventListener('click', async () => {
    $('check').disabled = true;
    $('update-text').textContent = 'در حال بررسی…';
    await chrome.runtime.sendMessage({ type: 'lens:check' });
    showStatus(await chrome.runtime.sendMessage({ type: 'lens:info' }));
    $('check').disabled = false;
  });
}
init();
